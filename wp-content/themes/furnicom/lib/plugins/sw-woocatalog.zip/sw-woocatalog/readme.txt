Plugin SW WooCommerce Catalog

== author: wpthemego
== Author Link: http://www.wpthemego.com/
== Description: A plugin help to display your woocommerce site as a catalog site.