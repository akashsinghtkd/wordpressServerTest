<?php 
/*
** Layout Countdown Category
*/

?>


<div class="sw-woo-tab-cat wootab-countdown-slider sw-ajax" >
<?php 
	$tag_id = $this->generateID();
	if( !is_array( $category ) ){
		$category = explode( ',', $category );
	}
?>
	<div class="resp-tab" style="position:relative;">
		<div class="top-tab-slider clearfix">
		<?php if( $title1 != '' ) : ?>
			<div class="order-title">
				<?php echo '<h2>'. $title1 .'</h2>'; ?>
			</div>
		<?php endif; ?>
			<ul class="nav nav-tabs">
			<?php 
				$i = 1;
				foreach($category as $key => $cat){
					$terms = get_term_by('id', $cat, 'product_cat');
					if( $terms && $terms->taxonomy == 'product_cat' ){	
					$thumbnail_id 	= absint( get_term_meta( $terms->term_id, 'thumbnail_id', true ));
					$thumb = wp_get_attachment_image( $thumbnail_id, array(350, 230) );					
			?>
				<li class="<?php if( $i == $tab_active ){echo 'active loaded'; }?>">
					<a href="#<?php echo esc_attr(  str_replace( '%', '', $cat ). '_' .$tag_id ) ?>" data-type="tab_ajax_countdown" data-layout="<?php echo esc_attr( $layout );?>" data-row="<?php echo esc_attr( $item_row ) ?>" data-length="<?php echo esc_attr( $title_length ) ?>" data-category="<?php echo esc_attr( $cat ) ?>" data-toggle="tab" data-sorder="<?php echo esc_attr( $select_order ); ?>" data-catload="ajax" data-number="<?php echo esc_attr( $numberposts ); ?>" data-lg="<?php echo esc_attr( $columns ); ?>" data-md="<?php echo esc_attr( $columns1 ); ?>" data-sm="<?php echo esc_attr( $columns2 ); ?>" data-xs="<?php echo esc_attr( $columns3 ); ?>" data-mobile="<?php echo esc_attr( $columns4 ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-scroll="<?php echo esc_attr( $scroll ); ?>" data-interval="<?php echo esc_attr( $interval ); ?>"  data-autoplay="<?php echo esc_attr( $autoplay ); ?>">
						<?php echo $thumb; ?>
						<h3>
							<?php echo $terms->name; ?>
						</h3>
					</a>
				</li>	
				<?php $i++; } ?>
			<?php } ?>
			</ul>
		</div>
		<div class="tab-content">
			<?php	
				$active = ( $tab_active - 1 >= 0 ) ? $tab_active - 1 : 0;
				$default = array(
					'post_type' => 'product',
					'tax_query' => array(
						array(
							'taxonomy'  => 'product_cat',
							'field'     => 'term_id',
							'terms'     => $category[$active] 
						)
					),	
					'meta_query' => array(							
						array(
							'key' => '_sale_price',
							'value' => 0,
							'compare' => '>',
							'type' => 'DECIMAL(10,5)'
						),
						array(
							'key' => '_sale_price_dates_to',
							'value' => 0,
							'compare' => '>',
							'type' => 'NUMERIC'
						)
					),
					'orderby' => $orderby,
					'order' => $order,
					'post_status' => 'publish',
					'showposts' => $numberposts	
				);	
				$list = new WP_Query( $default );
			?>
			<div class="tab-pane active" id="<?php echo esc_attr( str_replace( '%', '', $category[$active] ). '_' .$tag_id ) ?>">
				<?php if( $list->have_posts() ) : ?>
				<div id="<?php echo esc_attr( 'tab_cat_'. str_replace( '%', '', $category[$active] ). '_' .$tag_id ); ?>" class="woo-tab-container-slider responsive-slider countdown-slider clearfix loading" data-lg="<?php echo esc_attr( $columns ); ?>" data-md="<?php echo esc_attr( $columns1 ); ?>" data-sm="<?php echo esc_attr( $columns2 ); ?>" data-xs="<?php echo esc_attr( $columns3 ); ?>" data-mobile="<?php echo esc_attr( $columns4 ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-scroll="<?php echo esc_attr( $scroll ); ?>" data-interval="<?php echo esc_attr( $interval ); ?>" data-autoplay="<?php echo esc_attr( $autoplay ); ?>">
					<div class="resp-slider-container">
						<div class="slider responsive">
						<?php 							
							while($list->have_posts()): $list->the_post();
							global $product, $post;
							$class = ( $product->get_price_html() ) ? '' : 'item-nonprice';
							$id 			= get_the_ID();
							$start_time 	= get_post_meta( $post->ID, '_sale_price_dates_from', true );
							$countdown_time = get_post_meta( $post->ID, '_sale_price_dates_to', true );	
							$orginal_price 	= get_post_meta( $post->ID, '_regular_price', true );	
							$sale_price 	= get_post_meta( $post->ID, '_sale_price', true );	
							$symboy 		= get_woocommerce_currency_symbol( get_woocommerce_currency() );
						?>
							<div class="item <?php echo esc_attr( $class )?>">
								<div class="item-wrap">
									<div class="item-detail">										
										<div class="item-img products-thumb pull-left">											
											<!-- quickview & thumbnail  -->
												<?php do_action( 'woocommerce_before_shop_loop_item_title' ); ?>
										</div>										
										<div class="item-content">
											<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute();?>"><?php the_title(); ?></a></h4>								
											<?php if ( $price_html = $product->get_price_html() ){?>
												<div class="item-price">
													<span>
														<?php echo $price_html; ?>
													</span>
												</div>
											<?php } ?>
											<!-- rating  --> <?php if (  wc_review_ratings_enabled() ) { ?>
											<?php 
												$rating_count = $product->get_rating_count();
												$review_count = $product->get_review_count();
												$average      = $product->get_average_rating();
											?>
											<div class="reviews-content">
												<div class="star"><?php echo ( $average > 0 ) ?'<span style="width:'. ( $average*16 ).'px"></span>' : ''; ?></div>
											</div>	
											<?php } ?> <!-- end rating  -->
											<!-- Short Description -->
											<?php if ( $post->post_excerpt != '' ) {?>
											<div class="item-description"><?php echo wp_trim_words( $post->post_excerpt, 20 ); ?></div>
											<?php } ?>
											<!-- product countdown -->
											<div class="product-countdown"  data-price="<?php echo esc_attr( $symboy.$orginal_price ); ?>" data-starttime="<?php echo esc_attr( $start_time ); ?>" data-cdtime="<?php echo esc_attr( $countdown_time ); ?>" data-id="<?php echo 'product_'.$id.$post->ID; ?>"></div>	
										</div>											
									</div>
								</div>
							</div>
							<?php endwhile; wp_reset_postdata();?>
						</div>
					</div>
				</div>	
				<?php 
					else :
						echo '<div class="alert alert-warning alert-dismissible" role="alert">
						<a class="close" data-dismiss="alert">&times;</a>
						<p>'. esc_html__( 'There is not product on this tab', 'sw_woocommerce' ) .'</p>
						</div>';
					endif;				
				?>
			</div>	
		</div>
	</div>
</div>